package net.glxn.qrgen.core.scheme;

public class Foo {

}
